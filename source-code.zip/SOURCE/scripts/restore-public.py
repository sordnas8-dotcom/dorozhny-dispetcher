from pathlib import Path
from zipfile import ZipFile
root=Path(__file__).resolve().parents[1]
for part in sorted((root.parent/'PUBLISH').glob('site-part-*.zip')):
 with ZipFile(part) as z:
  for name in z.namelist():
   if name.startswith('docs/') and not name.startswith('docs/assets/'):
    target=root/'public'/name[5:]
    target.parent.mkdir(parents=True,exist_ok=True)
    target.write_bytes(z.read(name))
print('public restored; run npm ci and npm run build')
