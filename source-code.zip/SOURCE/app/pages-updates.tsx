import {useEffect,useState} from 'react';
import {FileSpreadsheet,ContactRound,Map,Truck,FolderArchive,Upload,Download,CheckCircle2} from 'lucide-react';
import {zipSync,unzipSync,strToU8,strFromU8} from 'fflate';
import {readTitul,normalizeTitul} from '../lib/titul';
import {parseContacts,normalizeContactBook} from '../lib/contacts';
import {initialTows,parseTows,towWorkbook} from '../lib/tows';
import type {SchemeFile} from '../lib/scheme-files';
import {mergeSchemes} from '../lib/scheme-files';
import {schemeUploadMetadata} from '../lib/scheme-upload-metadata';
import {siteUrl} from '../lib/pages-url';
function save(bytes:Uint8Array,name:string){const a=document.createElement('a'),url=URL.createObjectURL(new Blob([bytes as BlobPart],{type:'application/zip'}));a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),5000)}
type Kind='title'|'contacts'|'schemes'|'tow'|'archive';
export default function PagesUpdates({departments}:{departments:string[]}){
 const[kind,setKind]=useState<Kind>('title'),[deu,setDeu]=useState(departments[0]),[message,setMessage]=useState(''),[busy,setBusy]=useState(false),[changes,setChanges]=useState<Record<string,Uint8Array>>({}),[summary,setSummary]=useState<string[]>([]),[schemes,setSchemes]=useState<SchemeFile[]>([]),[accepted,setAccepted]=useState(false),[towBytes,setTowBytes]=useState<ArrayBuffer|null>(null),[sheets,setSheets]=useState<string[]>([]),[sheet,setSheet]=useState(''),[towName,setTowName]=useState('');
 useEffect(()=>{fetch(siteUrl('data/schemes.json'),{cache:'no-store'}).then(r=>{if(!r.ok)throw Error();return r.json()}).then(setSchemes).catch(()=>setMessage('Не удалось загрузить текущий список схем. Обновите страницу перед подготовкой пакета.'))},[]);
 function stage(path:string,value:unknown){setChanges(c=>({...c,[path]:strToU8(JSON.stringify(value,null,2))}));setAccepted(false)}
 async function pick(files:FileList|null,uploadKind:Kind){if(!files?.length)return;setBusy(true);setMessage('');try{
  if(uploadKind==='title'||uploadKind==='contacts'){
   const f=files[0];if(f.size>12*1024*1024)throw Error('Excel или JSON: не больше 12 МБ.');const bytes=await f.arrayBuffer();
   const data=uploadKind==='title'?normalizeTitul(/\.json$/i.test(f.name)?JSON.parse(new TextDecoder().decode(bytes)):readTitul(bytes,f.name)):normalizeContactBook(/\.json$/i.test(f.name)?JSON.parse(new TextDecoder().decode(bytes)):parseContacts(bytes,f.name));
   stage(`data/${uploadKind}.json`,data);setSummary(s=>[...s.filter(x=>!x.startsWith(uploadKind==='title'?'Титул:':'Контакты:')),uploadKind==='title'?`Титул: ${f.name}, ${'departments' in data?data.departments.length:0} подразделений`:`Контакты: ${f.name}, ${'contacts' in data?data.contacts.length:0} записей`]);
  }else if(uploadKind==='tow'){
   const f=files[0];if(f.size>12*1024*1024)throw Error('Excel: не больше 12 МБ.');const bytes=await f.arrayBuffer(),w=towWorkbook(bytes);setTowBytes(bytes);setTowName(f.name);setSheets(w.SheetNames);setSheet(w.SheetNames[0]);setMessage('Выберите лист и нажмите «Подготовить перечень».');
  }else if(uploadKind==='schemes'){
   let list=[...schemes];const pdfs:Record<string,Uint8Array>={};for(const f of Array.from(files)){
    if(!/\.pdf$/i.test(f.name)||f.size>50*1024*1024||!f.size)throw Error('Схемы: только PDF не больше 50 МБ.');const bytes=new Uint8Array(await f.arrayBuffer());if(strFromU8(bytes.subarray(0,5))!=='%PDF-')throw Error(`Не PDF: ${f.name}`);
    const old=list.find(x=>x.department===deu&&x.filename===f.name),id=old?.id||crypto.randomUUID(),path=old?.pdf?.startsWith('resources/')?old.pdf:`resources/schemes/${id}.pdf`;pdfs[path]=bytes;
    const item:SchemeFile={id,department:deu,...schemeUploadMetadata(f.name),filename:f.name,bytes:f.size,pdf:path,width:0,height:0,tiles:[],created:new Date().toISOString()};list=list.filter(x=>x.id!==id);list.push(item);
   }setSchemes(list);setChanges(c=>({...c,...pdfs,'data/schemes.json':strToU8(JSON.stringify(list,null,2))}));setAccepted(false);setSummary(s=>[...s,`Схемы: ${deu}, PDF — ${files.length}`]);
  }else{
   let list=[...schemes];const imported:Record<string,Uint8Array>={};let count=0;for(const f of Array.from(files)){
    if(f.size>150*1024*1024)throw Error('Архив не больше 150 МБ.');const zip=unzipSync(new Uint8Array(await f.arrayBuffer()),{filter:e=>e.originalSize<=50*1024*1024});
    const raw=zip['data/schemes.json'];if(!raw)throw Error('В архиве нет data/schemes.json. Используйте экспорт со старого сайта.');const records=JSON.parse(strFromU8(raw)) as SchemeFile[];
    for(const r of records){if(typeof r.id!=='string'||typeof r.department!=='string'||!/^resources\/schemes\/[a-zA-Z0-9_-]+\.pdf$/.test(r.pdf)||!zip[r.pdf]||strFromU8(zip[r.pdf].subarray(0,5))!=='%PDF-')throw Error('Архив содержит некорректную запись схемы.');imported[r.pdf]=zip[r.pdf];list=list.filter(x=>x.id!==r.id);list.push({...r,tiles:[],width:0,height:0});count++;}
   }setSchemes(list);setChanges(c=>({...c,...imported,'data/schemes.json':strToU8(JSON.stringify(list,null,2))}));setAccepted(false);setSummary(s=>[...s,`Перенос со старого сайта: ${count} PDF`]);
  }
 }catch(e){setMessage((e as Error).message)}finally{setBusy(false)}}
 function prepareTows(){try{if(!towBytes)return;const book=parseTows(towBytes,towName,sheet);stage('data/tows.json',book);setSummary(s=>[...s.filter(x=>!x.startsWith('Тягачи:')),`Тягачи: ${towName}, лист ${sheet}, меток — ${book.rows.length}`]);setMessage('Перечень подготовлен. Google-карта обновляется отдельно импортом KML.')}catch(e){setMessage((e as Error).message)}}
 const cards=[
 {id:'title' as Kind,title:'Титульные списки',description:'Площади, показатели и обслуживаемые ОДХ по ДЭУ.',format:'Excel или JSON · до 12 МБ',button:'Добавить титульный список',icon:FileSpreadsheet},
 {id:'contacts' as Kind,title:'Контакты ДЭУ',description:'Начальники, заместители, старшие мастера и мастера.',format:'Excel или JSON · до 12 МБ',button:'Добавить файл контактов',icon:ContactRound},
 {id:'schemes' as Kind,title:'Схемы уборки',description:'Выберите ДЭУ и добавьте одну или несколько схем.',format:'PDF · до 50 МБ на файл',button:'Добавить схемы уборки',icon:Map},
 {id:'tow' as Kind,title:'Тягачи',description:'Расстановка тягачей и данные для таблицы.',format:'Excel · до 12 МБ',button:'Добавить перечень тягачей',icon:Truck},
 {id:'archive' as Kind,title:'Перенос схем со старого сайта',description:'Добавьте ZIP-файлы, скачанные на странице экспорта.',format:'ZIP · до 150 МБ на архив',button:'Добавить архивы схем',icon:FolderArchive},
 ];
 return <section className="pages-updates" aria-label="Обновление данных">
 <div className="updates-intro"><h2>Что вы хотите обновить?</h2><p>Нажмите кнопку в нужном блоке и выберите файл на устройстве.</p></div>
 <div className="updates-cards">{cards.map(card=><article className={'updates-card updates-card-'+card.id+(kind===card.id?' is-selected':'')} key={card.id}>
 <div className="updates-card-heading"><span className="updates-card-icon"><card.icon size={24}/></span><h3>{card.title}</h3></div>
 <p>{card.description}</p>
 {card.id==='schemes'&&<label className="updates-department">Для какого ДЭУ?<select aria-label="Подразделение для схем" value={deu} disabled={busy} onChange={e=>{setKind('schemes');setDeu(e.target.value)}}>{departments.map(d=><option key={d}>{d}</option>)}</select></label>}
 <div className="updates-card-action"><span className="updates-file-format">{card.format}</span><label className={'updates-file-button'+(busy?' is-disabled':'')}><Upload size={19}/><span>{card.button}</span><input aria-label={card.button} type="file" multiple={card.id==='schemes'||card.id==='archive'} accept={card.id==='schemes'?'.pdf':card.id==='archive'?'.zip':card.id==='tow'?'.xlsx,.xls':'.xlsx,.xls,.json'} disabled={busy} onChange={e=>{setKind(card.id);void pick(e.target.files,card.id);e.target.value=''}}/></label></div>
 {card.id==='tow'&&sheets.length>0&&<div className="updates-tow-sheet"><label>Лист с тягачами<select aria-label="Лист тягачей" value={sheet} onChange={e=>setSheet(e.target.value)}>{sheets.map(s=><option key={s}>{s}</option>)}</select></label><button className="updates-action-button" disabled={busy} onClick={prepareTows}>Подготовить перечень</button></div>}
 </article>)}</div>
 {message&&<p className="import-alert updates-status" role="status">{message}</p>}{busy&&<p className="updates-status" role="status">Обработка файлов…</p>}
 {!!summary.length&&<section className="updates-package" aria-label="Подготовленный пакет"><div className="updates-card-heading"><span className="updates-card-icon"><CheckCircle2 size={24}/></span><h3>Файлы добавлены в пакет</h3></div><ul>{summary.map((s,i)=><li key={i}>{s}</li>)}</ul><p>Файлов для публикации: {Object.keys(changes).length}. Чтобы применить изменения на сайте, скачайте пакет и загрузите его в GitHub.</p><label className="updates-confirm"><input type="checkbox" checked={accepted} onChange={e=>setAccepted(e.target.checked)}/> Проверил состав обновления</label><button className="updates-action-button" disabled={!accepted||busy} onClick={()=>save(zipSync(Object.fromEntries(Object.entries(changes).map(([p,b])=>['docs/'+p,b])),{level:1}),`update_${new Date().toISOString().replace(/[:.]/g,'-')}_${crypto.randomUUID().slice(0,8)}.zip`)}><Download size={19}/>Скачать пакет обновления</button></section>}
 <aside className="updates-how"><h3>Как сохранить изменения для всех</h3><ol><li>Добавьте файлы с помощью кнопок выше.</li><li>Проверьте состав и скачайте пакет обновления.</li><li>Загрузите скачанный ZIP в <a href="https://github.com/sordnas8-dotcom/dorozhny-dispetcher/tree/main/updates" target="_blank" rel="noreferrer">папку updates на GitHub</a> и нажмите Commit changes. Дождитесь публикации.</li></ol><p>До публикации данные сайта не меняются. Не закрывайте страницу до скачивания пакета. Для исправления отдельных контактов загрузите исправленный Excel или JSON. Google-карта тягачей обновляется отдельно.</p></aside>
 </section>
}
