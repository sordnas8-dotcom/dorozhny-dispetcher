import {siteUrl} from '../lib/pages-url';
"use client";
import {useEffect,useMemo,useState} from 'react';
import {Search,X} from 'lucide-react';
import {mapCatalog,mapData,filterMapPoints,mapPointDetails,withoutCoordinatePairs,type MapKind,type MapPoint} from '../lib/map-catalog';

export default function MapDirectory({kind}:{kind:MapKind}){
 const [towBook,setTowBook]=useState<{rows:MapPoint[];filename:string}|null>(null),[towError,setTowError]=useState('');
 useEffect(()=>{if(kind!=='tow')return;let live=true;fetch(siteUrl('data/tows.json'),{cache:'no-store'}).then(async r=>{if(r.status===401)return;const b=await r.json() as {error?:string;current:string;title:{rows:MapPoint[];filename:string}};if(!r.ok)throw Error(b.error);if(live)setTowBook(b as unknown as {rows:MapPoint[];filename:string})}).catch(()=>{if(live)setTowError('Не удалось загрузить актуальный перечень тягачей. Обновите страницу.');});return()=>{live=false}},[kind]);
 const config=mapCatalog[kind],{mapId}=mapData[kind],rows=kind==='tow'&&towBook?towBook.rows:mapData[kind].rows;
 const [group,setGroup]=useState(''),[search,setSearch]=useState(''),[selected,setSelected]=useState('');
 const filtered=filterMapPoints(rows,group,search);
 const filters=useMemo(()=>[...new Set(rows.flatMap(p=>p.filters))].sort((a,b)=>kind==='deu'?a.localeCompare(b,'ru',{numeric:true}):0),[rows,kind]);
 const legend=useMemo(()=>[...new Map(rows.map(p=>[p.group,{label:p.group,color:p.color}])).values()],[rows]);
 const point=rows.find(p=>p.id===selected);
 const mapUrl=`https://www.google.com/maps/d/viewer?mid=${mapId}${point?`&ll=${point.lat},${point.lon}&z=15`:''}`;
 const embedUrl=`https://www.google.com/maps/d/embed?mid=${mapId}${point?`&ll=${point.lat},${point.lon}&z=15`:''}`;
 const groups=kind==='ssp'?legend.map(l=>({label:l.label,points:filtered.filter(p=>p.group===l.label)})).filter(g=>g.points.length):[{label:'',points:filtered}];
 function select(p:MapPoint){setSelected(p.id)}
 function cellValue(p:MapPoint,field:string){const value=withoutCoordinatePairs(p.fields[field]||'');return value?field==='Производительность'?Number(value).toLocaleString('ru-RU'):value:'—'}
 return <>
  {towError&&<p className="import-alert" role="alert">{towError}</p>}
  {kind==='tow'&&towBook&&<p className="import-alert">Таблица: {towBook.filename}. Google-карта обновляется отдельно импортом KML из раздела «Обновление данных → Тягачи».</p>}
  <div className="filters ssp-filters"><label className="search"><Search size={17}/><input aria-label={`Поиск: ${config.tag}`} placeholder={config.placeholder} value={search} onChange={e=>{setSearch(e.target.value);setSelected('')}}/></label><select aria-label={config.filter} value={group} onChange={e=>{setGroup(e.target.value);setSelected('')}}><option value="">{config.all}</option>{filters.map(f=><option key={f} value={f}>{f}</option>)}</select><span role="status">Найдено: {filtered.length} из {rows.length}</span></div>
  <div className="ssp-google-actions"><a className="button secondary" href={mapUrl} target="_blank" rel="noreferrer">Открыть карту в Google</a><small>Поиск и фильтр применяются к таблице. Выберите строку, чтобы открыть сведения и приблизить точку на карте.</small></div>
  <iframe title={`${config.title} — Google My Maps`} className="map-frame" src={embedUrl} loading="lazy" allowFullScreen/>
  <div className="ssp-legend">{legend.map(l=><span key={l.label}><i style={{background:l.color}}/>{l.label}</span>)}</div>
  {point&&<section className="map-point-detail" aria-label={`Сведения: ${point.name}`}><div className="map-point-heading"><h3>{kind==='ssp'?`${point.number}. ${point.name} · ${point.group}`:`${point.number}. ${point.name}`}</h3><button className="icon-btn" aria-label="Закрыть сведения" onClick={()=>setSelected('')}><X size={18}/></button></div><dl>{mapPointDetails(point).map(([key,value])=><div key={key}><dt>{key}</dt><dd>{value}</dd></div>)}</dl></section>}
  <div className="table-scroll map-directory-table"><table><thead><tr><th>{kind==='ssp'?'№ у владельца':'№'}</th><th>Наименование</th>{config.columns.map(c=><th key={c.field}>{c.label}</th>)}</tr></thead><tbody>{groups.flatMap(g=>[...(g.label?[<tr className="map-owner-heading" key={'group-'+g.label}><th scope="rowgroup" colSpan={config.columns.length+2}>{g.label} <span>{g.points.length} ССП</span></th></tr>]:[]),...g.points.map(p=><tr key={p.id} className={selected===p.id?'map-point-selected':''} tabIndex={0} onKeyDown={e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();select(p)}}} onClick={()=>select(p)}><td><span className="map-number" style={{borderColor:p.color}}>{p.number}</span></td><td className="wrap"><strong>{p.name}</strong></td>{config.columns.map(c=><td key={c.field} className="wrap">{cellValue(p,c.field)}</td>)}</tr>)])}</tbody></table>{!filtered.length&&<p className="map-empty" role="status">Ничего не найдено. Измените поиск или фильтр.</p>}</div>

 </>;
}
