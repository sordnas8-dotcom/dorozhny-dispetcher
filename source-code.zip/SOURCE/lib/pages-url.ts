export function siteUrl(path:string){return new URL(path.replace(/^\//,''),new URL('.',document.baseURI)).href;}
