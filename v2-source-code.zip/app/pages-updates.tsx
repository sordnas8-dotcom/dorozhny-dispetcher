import {useEffect,useState} from 'react';
import {Upload} from 'lucide-react';
import {zipSync,unzipSync,strToU8,strFromU8} from 'fflate';
import {readTitul,normalizeTitul} from '../lib/titul';
import {parseContacts,normalizeContactBook} from '../lib/contacts';
import {initialTows,parseTows,towWorkbook} from '../lib/tows';
import type {SchemeFile} from '../lib/scheme-files';
import {mergeSchemes} from '../lib/scheme-files';
import {schemeUploadMetadata} from '../lib/scheme-upload-metadata';
import {siteUrl} from '../lib/pages-url';
function save(bytes:Uint8Array,name:string){const a=document.createElement('a'),url=URL.createObjectURL(new Blob([bytes as BlobPart],{type:'application/zip'}));a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),5000)}
type Kind='title'|'contacts'|'schemes'|'tow'|'archive';
export default function PagesUpdates({departments}:{departments:string[]}){
 const[kind,setKind]=useState<Kind>('title'),[deu,setDeu]=useState(departments[0]),[message,setMessage]=useState(''),[busy,setBusy]=useState(false),[changes,setChanges]=useState<Record<string,Uint8Array>>({}),[summary,setSummary]=useState<string[]>([]),[schemes,setSchemes]=useState<SchemeFile[]>([]),[accepted,setAccepted]=useState(false),[towBytes,setTowBytes]=useState<ArrayBuffer|null>(null),[sheets,setSheets]=useState<string[]>([]),[sheet,setSheet]=useState(''),[towName,setTowName]=useState('');
 useEffect(()=>{fetch(siteUrl('data/schemes.json'),{cache:'no-store'}).then(r=>{if(!r.ok)throw Error();return r.json()}).then(setSchemes).catch(()=>setMessage('Не удалось загрузить текущий список схем. Обновите страницу перед подготовкой пакета.'))},[]);
 function stage(path:string,value:unknown){setChanges(c=>({...c,[path]:strToU8(JSON.stringify(value,null,2))}));setAccepted(false)}
 async function pick(files:FileList|null){if(!files?.length)return;setBusy(true);setMessage('');try{
  if(kind==='title'||kind==='contacts'){
   const f=files[0];if(f.size>12*1024*1024)throw Error('Excel или JSON: не больше 12 МБ.');const bytes=await f.arrayBuffer();
   const data=kind==='title'?normalizeTitul(/\.json$/i.test(f.name)?JSON.parse(new TextDecoder().decode(bytes)):readTitul(bytes,f.name)):normalizeContactBook(/\.json$/i.test(f.name)?JSON.parse(new TextDecoder().decode(bytes)):parseContacts(bytes,f.name));
   stage(`data/${kind}.json`,data);setSummary(s=>[...s.filter(x=>!x.startsWith(kind==='title'?'Титул:':'Контакты:')),kind==='title'?`Титул: ${f.name}, ${'departments' in data?data.departments.length:0} подразделений`:`Контакты: ${f.name}, ${'contacts' in data?data.contacts.length:0} записей`]);
  }else if(kind==='tow'){
   const f=files[0];if(f.size>12*1024*1024)throw Error('Excel: не больше 12 МБ.');const bytes=await f.arrayBuffer(),w=towWorkbook(bytes);setTowBytes(bytes);setTowName(f.name);setSheets(w.SheetNames);setSheet(w.SheetNames[0]);setMessage('Выберите лист и нажмите «Подготовить перечень».');
  }else if(kind==='schemes'){
   let list=[...schemes];const pdfs:Record<string,Uint8Array>={};for(const f of Array.from(files)){
    if(!/\.pdf$/i.test(f.name)||f.size>50*1024*1024||!f.size)throw Error('Схемы: только PDF не больше 50 МБ.');const bytes=new Uint8Array(await f.arrayBuffer());if(strFromU8(bytes.subarray(0,5))!=='%PDF-')throw Error(`Не PDF: ${f.name}`);
    const old=list.find(x=>x.department===deu&&x.filename===f.name),id=old?.id||crypto.randomUUID(),path=old?.pdf?.startsWith('resources/')?old.pdf:`resources/schemes/${id}.pdf`;pdfs[path]=bytes;
    const item:SchemeFile={id,department:deu,...schemeUploadMetadata(f.name),filename:f.name,bytes:f.size,pdf:path,width:0,height:0,tiles:[],created:new Date().toISOString()};list=list.filter(x=>x.id!==id);list.push(item);
   }setSchemes(list);setChanges(c=>({...c,...pdfs,'data/schemes.json':strToU8(JSON.stringify(list,null,2))}));setAccepted(false);setSummary(s=>[...s,`Схемы: ${deu}, PDF — ${files.length}`]);
  }else{
   let list=[...schemes];const imported:Record<string,Uint8Array>={};let count=0;for(const f of Array.from(files)){
    if(f.size>150*1024*1024)throw Error('Архив не больше 150 МБ.');const zip=unzipSync(new Uint8Array(await f.arrayBuffer()),{filter:e=>e.originalSize<=50*1024*1024});
    const raw=zip['data/schemes.json'];if(!raw)throw Error('В архиве нет data/schemes.json. Используйте экспорт со старого сайта.');const records=JSON.parse(strFromU8(raw)) as SchemeFile[];
    for(const r of records){if(typeof r.id!=='string'||typeof r.department!=='string'||!/^resources\/schemes\/[a-zA-Z0-9_-]+\.pdf$/.test(r.pdf)||!zip[r.pdf]||strFromU8(zip[r.pdf].subarray(0,5))!=='%PDF-')throw Error('Архив содержит некорректную запись схемы.');imported[r.pdf]=zip[r.pdf];list=list.filter(x=>x.id!==r.id);list.push({...r,tiles:[],width:0,height:0});count++;}
   }setSchemes(list);setChanges(c=>({...c,...imported,'data/schemes.json':strToU8(JSON.stringify(list,null,2))}));setAccepted(false);setSummary(s=>[...s,`Перенос со старого сайта: ${count} PDF`]);
  }
 }catch(e){setMessage((e as Error).message)}finally{setBusy(false)}}
 function prepareTows(){try{if(!towBytes)return;const book=parseTows(towBytes,towName,sheet);stage('data/tows.json',book);setSummary(s=>[...s.filter(x=>!x.startsWith('Тягачи:')),`Тягачи: ${towName}, лист ${sheet}, меток — ${book.rows.length}`]);setMessage('Перечень подготовлен. Google-карта обновляется отдельно импортом KML.')}catch(e){setMessage((e as Error).message)}}
 return <section className="panel" style={{padding:24}}><h2>Подготовка обновления сайта</h2><p>Выбранные файлы обрабатываются на этом устройстве. Посетители увидят изменения после загрузки ZIP в папку updates репозитория GitHub и публикации.</p><div className="map-tabs">{([['title','Титул'],['contacts','Контакты'],['schemes','Схемы'],['tow','Тягачи'],['archive','Перенос схем']] as [Kind,string][]).map(([id,label])=><button className={kind===id?'active':''} key={id} onClick={()=>{setKind(id);setMessage('')}}>{label}</button>)}</div>
 {kind==='schemes'&&<label>Подразделение <select value={deu} onChange={e=>setDeu(e.target.value)}>{departments.map(d=><option key={d}>{d}</option>)}</select></label>}
 {kind==='archive'&&<p>Загрузите ZIP из страницы /export действующего сайта. Части архива можно добавлять последовательно до скачивания пакета обновления.</p>}
 <p className="pages-file-picker-row"><label className="pages-file-picker"><Upload size={18}/><span>Выберите файл</span><input aria-label="Выберите файл" key={kind} type="file" multiple={kind==='schemes'||kind==='archive'} accept={kind==='schemes'?'.pdf':kind==='archive'?'.zip':kind==='tow'?'.xlsx,.xls':'.xlsx,.xls,.json'} disabled={busy} onChange={e=>{void pick(e.target.files);e.target.value=''}}/></label></p>
 {kind==='tow'&&sheets.length>0&&<p><select aria-label="Лист тягачей" value={sheet} onChange={e=>setSheet(e.target.value)}>{sheets.map(s=><option key={s}>{s}</option>)}</select> <button className="button secondary" onClick={prepareTows}>Подготовить перечень</button></p>}
 {message&&<p className="import-alert" role="status">{message}</p>}{busy&&<p>Обработка файлов…</p>}
 {!!summary.length&&<><h3>Состав пакета</h3><ul>{summary.map((s,i)=><li key={i}>{s}</li>)}</ul><p>Файлов для публикации: {Object.keys(changes).length}. Текущая опубликованная версия пока не изменена.</p><label className="accept-import"><input type="checkbox" checked={accepted} onChange={e=>setAccepted(e.target.checked)}/> Проверил состав обновления.</label><button className="button primary" disabled={!accepted||busy} onClick={()=>save(zipSync(Object.fromEntries(Object.entries(changes).map(([p,b])=>['docs/'+p,b])),{level:1}),`update_${new Date().toISOString().replace(/[:.]/g,'-')}_${crypto.randomUUID().slice(0,8)}.zip`)}>Скачать пакет обновления</button></>}
</section>
}
