import {siteUrl} from '../lib/pages-url';
"use client";
import {useEffect,useRef,useState} from 'react';
import type {PDFDocumentProxy,PDFPageProxy} from 'pdfjs-dist';
import {Minus,Plus,RefreshCw} from 'lucide-react';
import {previewGeometry} from '../lib/pdf-preview';

export default function PdfQuickView({url,name}:{url:string;name:string}){
 const [document,setDocument]=useState<PDFDocumentProxy|null>(null),[page,setPage]=useState<PDFPageProxy|null>(null),[number,setNumber]=useState(1),[zoom,setZoom]=useState(.75),[error,setError]=useState(''),[attempt,setAttempt]=useState(0),[loading,setLoading]=useState(true);
 const viewport=useRef<HTMLDivElement>(null);
 useEffect(()=>{
  let live=true;let task:ReturnType<typeof import('pdfjs-dist')['getDocument']>|undefined;
  setDocument(null);setPage(null);setNumber(1);setError('');setLoading(true);
  (async()=>{try{const pdfjs=await import('pdfjs-dist');if(!live)return;pdfjs.GlobalWorkerOptions.workerSrc=siteUrl(`/pdfjs/${pdfjs.version}/pdf.worker.min.mjs`);
   task=pdfjs.getDocument({url,withCredentials:true,cMapUrl:siteUrl(`/pdfjs/${pdfjs.version}/cmaps/`),cMapPacked:true,standardFontDataUrl:siteUrl(`/pdfjs/${pdfjs.version}/standard_fonts/`),wasmUrl:siteUrl(`/pdfjs/${pdfjs.version}/wasm/`)});
   const doc=await task.promise;if(live)setDocument(doc);
  }catch(e){if(live){const status=(e as {status?:number}).status;setError(status===401?'Войдите в сайт, чтобы открыть загруженную схему.':status===404?'Файл схемы недоступен. Обновите список схем.':(e as Error).name==='PasswordException'?'PDF защищён паролем. Откройте его отдельно.':'Не удалось построить быстрый просмотр. Повторите попытку или откройте PDF.');setLoading(false)}}})();
  return()=>{live=false;void task?.destroy().catch(()=>{})};
 },[url,attempt]);
 useEffect(()=>{if(!document)return;let live=true;setLoading(true);setError('');setPage(null);document.getPage(number).then(p=>{if(live){setPage(p);setLoading(false);viewport.current?.scrollTo(0,0)}}).catch(()=>{if(live){setError('Не удалось открыть этот лист PDF. Повторите попытку.');setLoading(false)}});return()=>{live=false}},[document,number]);
 const original=page?.getViewport({scale:1}),geometry=original?previewGeometry(original.width,original.height,zoom):null;
 return <div className="pdf-quick-view">
  <div className="scheme-viewer-toolbar"><div className="scheme-zoom"><button type="button" className="icon-btn" aria-label="Уменьшить схему" disabled={zoom<=.25} onClick={()=>setZoom(z=>Math.max(.25,z-.25))}><Minus size={18}/></button><span aria-live="polite">{Math.round(zoom*100)}%</span><button type="button" className="icon-btn" aria-label="Увеличить схему" disabled={zoom>=2} onClick={()=>setZoom(z=>Math.min(2,z+.25))}><Plus size={18}/></button><button type="button" className="text-button" onClick={()=>setZoom(Math.min(2,Math.max(.25,(viewport.current?.clientHeight||675)/900)))}>По высоте</button></div>{document&&<label className="pdf-page-select">Лист<select aria-label="Лист схемы" value={number} onChange={e=>setNumber(Number(e.target.value))}>{Array.from({length:document.numPages},(_,i)=><option key={i+1} value={i+1}>{i+1}</option>)}</select><span>из {document.numPages}</span></label>}<span className="quick-view-label">Быстрый просмотр</span></div>
  {error?<div className="pdf-preview-error" role="alert"><p>{error}</p><button type="button" className="button secondary" onClick={()=>setAttempt(a=>a+1)}><RefreshCw size={16}/>Повторить просмотр</button></div>:<><p className="scheme-pan-hint">Двигайте схему по горизонтали и вертикали. Листы PDF открываются отдельно.</p><div ref={viewport} className="scheme-viewport pdf-quick-viewport" tabIndex={0} role="region" aria-label={`Быстрый просмотр: ${name}`} aria-busy={loading}>{loading&&<p className="pdf-preview-loading" role="status">Подготовка быстрого просмотра…</p>}{page&&geometry&&<div className="pdf-canvas-strip" style={{width:geometry.width,height:geometry.height}}>{geometry.tiles.map((tile,i)=><PdfTile key={`${page.pageNumber}-${zoom}-${i}`} page={page} root={viewport.current} scale={geometry.scale} left={tile.left} width={tile.width} height={geometry.height} label={`${name}, лист ${number}, фрагмент ${i+1}`}/>)}</div>}</div></>}
 </div>;
}
function PdfTile({page,root,scale,left,width,height,label}:{page:PDFPageProxy;root:HTMLDivElement|null;scale:number;left:number;width:number;height:number;label:string}){
 const tile=useRef<HTMLDivElement>(null),canvas=useRef<HTMLCanvasElement>(null);const [visible,setVisible]=useState(false),[state,setState]=useState('loading'),[retry,setRetry]=useState(0);
 useEffect(()=>{const node=tile.current;if(!node)return;const observer=new IntersectionObserver(entries=>setVisible(entries[0].isIntersecting),{root,rootMargin:'1024px'});observer.observe(node);return()=>observer.disconnect()},[root]);
 useEffect(()=>{const node=canvas.current;if(!visible||!node)return;const context=node.getContext('2d');if(!context)return;let live=true;const dpr=Math.min(window.devicePixelRatio||1,2);node.width=Math.ceil(width*dpr);node.height=Math.ceil(height*dpr);setState('loading');
  const task=page.render({canvas:node,viewport:page.getViewport({scale}),transform:[dpr,0,0,dpr,-left*dpr,0]});
  task.promise.then(()=>{if(live)setState('ready')}).catch(e=>{if(live&&e.name!=='RenderingCancelledException')setState('error')});
  return()=>{live=false;task.cancel();void task.promise.catch(()=>{}).then(()=>{node.width=0;node.height=0})};
 },[visible,page,scale,left,width,height,retry]);
 return <div ref={tile} className="pdf-canvas-tile" style={{width,height}}>{visible&&<canvas key={retry} ref={canvas} role="img" aria-label={label} style={{width,height}}/>}{visible&&state==='loading'&&<span className="pdf-tile-state">Загрузка фрагмента…</span>}{visible&&state==='error'&&<button type="button" className="button secondary pdf-tile-state" onClick={()=>setRetry(n=>n+1)}>Повторить загрузку фрагмента</button>}</div>;
}
