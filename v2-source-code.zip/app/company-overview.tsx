import {Building2,Layers} from 'lucide-react';
import DepartmentAreaChart from './department-area-chart';
import type {Titul} from '../lib/titul';
import {companySummary} from '../lib/company-summary';
export default function CompanyOverview({title,onSelect}:{title:Titul;onSelect:(name:string)=>void}){
 const indicators=companySummary(title);
 return <div className="company-overview"><div className="department-heading"><div><h2>Всего по ГБУ</h2></div><span className="company-count"><Building2 size={16}/>{title.departments.length} подразделений</span></div><section className="stats company-stats" aria-label="Общие показатели ГБУ">{indicators.map((item,i)=><article className="stat-card" key={item.id}><div className="stat-top"><span>{item.label}</span><span className={'stat-icon '+['orange','blue','green','purple'][i%4]}><Layers size={18}/></span></div><strong className="deu-value">{item.value==null?'—':item.value.toLocaleString('ru-RU',{maximumFractionDigits:4})}</strong><small>{item.unit}</small>{item.missing>0&&<p className="summary-missing">{item.value==null?'Показатель отсутствует':`Неполные данные: ${item.missing} подразделений`}</p>}</article>)}</section><DepartmentAreaChart title={title} onSelect={onSelect}/></div>;
}
