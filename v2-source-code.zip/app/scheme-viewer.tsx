"use client";
import {useEffect,useRef} from 'react';
import {Download,ExternalLink,X} from 'lucide-react';
import type {SchemeFile} from '../lib/scheme-files';
import PdfQuickView from './pdf-quick-view';
export default function SchemeViewer({file,onClose}:{file:SchemeFile;onClose:()=>void}){
 const section=useRef<HTMLElement>(null);
 useEffect(()=>{section.current?.scrollIntoView({behavior:'smooth',block:'start'})},[file.id]);
 return <section ref={section} className="scheme-viewer" aria-label={`Просмотр схемы: ${file.name}`}><div className="scheme-viewer-heading"><div><h3>{file.name}</h3><p>{file.department}{file.season&&` · ${file.season}`}</p></div><button type="button" className="icon-btn" aria-label="Закрыть схему" onClick={onClose}><X size={18}/></button></div><div className="scheme-original-actions"><a className="text-button" href={file.pdf+'#pagemode=thumbs'} target="_blank" rel="noreferrer"><ExternalLink size={15}/>Открыть PDF</a><a className="text-button" href={file.pdf.startsWith('/api/')?file.pdf+'&download=1':file.pdf} download={file.filename}><Download size={15}/>Скачать PDF</a></div><PdfQuickView key={file.id} url={file.pdf} name={file.name}/></section>;
}
