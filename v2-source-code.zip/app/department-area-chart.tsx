"use client";
import {useMemo,useState} from 'react';
import type {Titul} from '../lib/titul';
import {companySummary} from '../lib/company-summary';
import {compareDepartments} from '../lib/departments';

export default function DepartmentAreaChart({title,onSelect}:{title:Titul;onSelect:(name:string)=>void}){
 const [order,setOrder]=useState('department');
 const data=useMemo(()=>{
  const total=companySummary(title).find(i=>i.id==='area')!;
  const rows=title.departments.map(department=>{
   const area=companySummary({...title,departments:[department]}).find(i=>i.id==='area')!;
   return {name:department.name,value:area.value,missing:area.missing,share:total.value&&area.value!=null?area.value/total.value*100:null};
  });
  return {total,rows};
 },[title]);
 const rows=[...data.rows].sort((a,b)=>order==='area'?(b.value??-1)-(a.value??-1)||compareDepartments(a.name,b.name):compareDepartments(a.name,b.name));
 const largest=Math.max(0,...rows.map(row=>row.share??0));
 const scale=Math.max(5,Math.ceil(largest/5)*5);
 const number=(value:number)=>value.toLocaleString('ru-RU',{maximumFractionDigits:4});
 const percent=(value:number)=>value.toLocaleString('ru-RU',{minimumFractionDigits:2,maximumFractionDigits:2})+'%';
 return <section className="panel department-area-chart" aria-label="Распределение общей площади ОДХ по подразделениям">
  <div className="panel-heading"><div><h2>Общая площадь ОДХ по ДЭУ</h2><p>{data.total.value==null?'Нет данных об общей площади':`100% = ${number(data.total.value)} м²`}</p></div><label className="area-sort">Порядок<select aria-label="Порядок ДЭУ на диаграмме" value={order} onChange={e=>setOrder(e.target.value)}><option value="department">По ДЭУ</option><option value="area">По площади</option></select></label></div>
  {data.total.missing>0&&<p className="area-chart-note">Расчёт по имеющимся данным. Неполные показатели у {data.total.missing} подразделений.</p>}
  <div className="area-chart-columns" aria-hidden="true"><span>Подразделение</span><div className="area-chart-axis"><span>0%</span><span>{percent(scale/2)}</span><span>{percent(scale)}</span></div><span>Площадь, м² · Доля</span></div>
  <div className="area-chart-scroll" tabIndex={0} role="region" aria-label="Все подразделения на диаграмме">
   {rows.map(row=><button type="button" className="area-chart-row" key={row.name} onClick={()=>onSelect(row.name)} aria-label={`${row.name}: ${row.value==null?'нет данных':number(row.value)+' м²'}, ${row.share==null?'доля не определена':percent(row.share)}. Открыть подразделение`}>
    <span className="area-chart-name">{row.name}</span><span className="area-chart-track" aria-hidden="true"><span className={'area-chart-bar '+(/Инженер/.test(row.name)?'contractor':'')} style={{width:`${(row.share??0)/scale*100}%`}}/></span><span className="area-chart-value"><strong>{row.value==null?'—':number(row.value)}</strong><span>{row.share==null?'—':percent(row.share)}{row.missing>0?' *':''}</span></span>
   </button>)}
  </div>
 </section>;
}
