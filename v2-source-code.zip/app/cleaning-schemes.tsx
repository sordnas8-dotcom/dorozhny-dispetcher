import {siteUrl} from '../lib/pages-url';
"use client";
import {useCallback,useEffect,useRef,useState} from 'react';
import {Download,FileText,RefreshCw} from 'lucide-react';
import files from '../lib/cleaning-schemes.json';
import {mergeSchemes,type SchemeFile} from '../lib/scheme-files';
import {departmentName} from '../lib/departments';
import SchemeViewer from './scheme-viewer';
export default function CleaningSchemes({department}:{department:string}){
 const [uploaded,setUploaded]=useState<SchemeFile[]>([]),[listError,setListError]=useState(''),[loading,setLoading]=useState(false),[selected,setSelected]=useState('');
 const viewer=useRef<HTMLDivElement>(null);
 const schemes=mergeSchemes(files,uploaded).filter(file=>departmentName(file.department)===departmentName(department));
 const load=useCallback(()=>{const controller=new AbortController();setLoading(true);fetch(siteUrl('data/schemes.json'),{cache:'no-store',signal:controller.signal}).then(async r=>{const b=await r.json() as {error?:string;files:SchemeFile[]};if(!r.ok)throw Error(b.error||'Не удалось загрузить схемы');setUploaded((b as unknown as SchemeFile[]).map(f=>({...f,pdf:siteUrl(f.pdf)})));setListError('')}).catch(e=>{if(e.name!=='AbortError')setListError((e as Error).message)}).finally(()=>{if(!controller.signal.aborted)setLoading(false)});return()=>controller.abort()},[]);
 useEffect(()=>load(),[load,department]);
 useEffect(()=>{const refresh=()=>{load()};window.addEventListener('focus',refresh);window.addEventListener('schemes-updated',refresh);return()=>{window.removeEventListener('focus',refresh);window.removeEventListener('schemes-updated',refresh)}},[load]);
 useEffect(()=>{setSelected('')},[department]);
 useEffect(()=>{if(selected)viewer.current?.scrollIntoView({behavior:'smooth',block:'start'})},[selected]);
 const active=schemes.find(file=>file.id===selected);
 return <section className="cleaning-schemes"><div className="schemes-heading"><h3>Схемы уборки · {department}</h3><span>{schemes.length?`Схем: ${schemes.length}`:'Нет схем'}</span><button type="button" className="text-button" disabled={loading} onClick={()=>load()}><RefreshCw size={15}/>{loading?'Обновление…':'Обновить список'}</button></div>{listError&&<p className="import-alert" role="alert">{listError} <button type="button" className="text-button" onClick={()=>load()}>Повторить загрузку списка</button></p>}{schemes.length?<><div className="scheme-list">{schemes.map(file=><article className={'scheme-card '+(file.id===selected?'selected':'')} key={file.id}><FileText size={22}/><div><h4>{file.name}</h4><p>{file.season&&`${file.season} · `}PDF · {(file.bytes/1024/1024).toLocaleString('ru-RU',{maximumFractionDigits:1})} МБ</p><div className="scheme-actions"><button type="button" className="text-button" onClick={()=>setSelected(file.id)}>Смотреть схему</button><a className="text-button" href={file.pdf.startsWith('/api/')?file.pdf+'&download=1':file.pdf} download={file.filename}><Download size={15}/>Скачать PDF</a></div></div></article>)}</div><div ref={viewer}>{active?<SchemeViewer file={active} onClose={()=>setSelected('')}/>:<div className="scheme-placeholder"><FileText size={28}/><p>Выберите схему — быстрый просмотр откроется сразу.</p></div>}</div></>:<p className="map-foot">{loading?'Загрузка схем…':listError?'Не удалось получить загруженные схемы. Повторите загрузку списка.':'Для этого подразделения схемы пока не добавлены.'}</p>}</section>;
}
