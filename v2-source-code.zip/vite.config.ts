import {defineConfig} from 'vite';import react from '@vitejs/plugin-react';export default defineConfig({base:'./',plugins:[react()],build:{outDir:'dist/v2',emptyOutDir:true}});
