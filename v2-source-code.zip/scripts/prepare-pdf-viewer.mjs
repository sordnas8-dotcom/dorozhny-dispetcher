import {cp,mkdir,readFile,rm} from 'node:fs/promises';
import {createRequire} from 'node:module';
import path from 'node:path';
const require=createRequire(import.meta.url);
const root=path.dirname(require.resolve('pdfjs-dist/package.json'));
const {version}=JSON.parse(await readFile(path.join(root,'package.json'),'utf8'));
const target=path.resolve('public/pdfjs',version);await mkdir(target,{recursive:true});
for(const part of ['build/pdf.worker.min.mjs','cmaps','standard_fonts','wasm'])await cp(path.join(root,part),path.join(target,path.basename(part)),{recursive:true});
console.log(`Prepared PDF viewer assets ${version}`);
