from pathlib import Path
from zipfile import ZipFile
from PIL import Image
import fitz,json,io,hashlib
workspace=Path(__file__).resolve().parents[2];root=workspace/'road-v2';base=workspace/'github-pages';rows=json.loads((workspace/'github-publication/migration-8-9-10/schemes.json').read_text());exported={}
for n in range(1,11):
 with ZipFile(workspace/'upload'/f'Схемы_для_переноса_{n}.zip') as z:
  for name in z.namelist():
   if name.endswith('.pdf'):exported[name]=z.read(name)
thumbs=root/'public/thumbs';thumbs.mkdir(parents=True,exist_ok=True)
for row in rows:
 path=row['pdf'].lstrip('/');data=exported.get(path)
 if data is None:data=(base/'public'/path).read_bytes()
 doc=fitz.open(stream=data,filetype='pdf');page=doc[0];rect=page.rect
 if rect.width/rect.height>5:
  width=rect.height*2.8;left=max(0,(rect.width-width)/2);rect=fitz.Rect(left,0,left+width,rect.height)
 scale=min(640/rect.width,260/rect.height);pix=page.get_pixmap(matrix=fitz.Matrix(scale,scale),clip=rect,alpha=False)
 Image.frombytes('RGB',[pix.width,pix.height],pix.samples).save(thumbs/(row['id']+'.jpg'),'JPEG',quality=85,optimize=True)
 doc.close()
print(f'Thumbnails: {len(rows)}; all linked to original PDFs')
