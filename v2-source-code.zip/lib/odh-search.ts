import type {Department} from './titul';
export type OdhOwner={department:string;object:Department['objects'][number]};
export type OdhResult={id:string;name:string;owners:OdhOwner[];names:string[]};
const normalize=(s:string)=>s.toLocaleLowerCase('ru').replace(/ё/g,'е').replace(/[^\p{L}\p{N}]+/gu,' ').trim();
export function indexObjects(departments:Department[]){const map=new Map<string,OdhResult>();for(const d of departments)for(const o of d.objects){const id=o.id||o.name;let result=map.get(id);if(!result){result={id:o.id,name:o.name,owners:[],names:[]};map.set(id,result)}if(!result.names.includes(o.name))result.names.push(o.name);const existing=result.owners.find(x=>x.department===d.name);if(!existing)result.owners.push({department:d.name,object:o});else if(existing.object.additional&&!o.additional)existing.object=o;}return [...map.values()]}
export function findObjects(index:OdhResult[],query:string){const q=normalize(query);if(!q)return [];const terms=q.split(' ');return index.filter(o=>{const hay=normalize(`${o.id} ${o.names.join(' ')}`);return terms.every(t=>hay.includes(t))}).sort((a,b)=>Number(b.id===query.trim())-Number(a.id===query.trim()))}
