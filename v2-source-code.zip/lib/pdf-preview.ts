export const PDF_PREVIEW_HEIGHT=900;
export const PDF_TILE_WIDTH=1024;
export function previewGeometry(width:number,height:number,zoom:number){
 const scale=PDF_PREVIEW_HEIGHT*zoom/height;
 const pixelWidth=width*scale,pixelHeight=height*scale;
 return {scale,width:pixelWidth,height:pixelHeight,tiles:Array.from({length:Math.ceil(pixelWidth/PDF_TILE_WIDTH)},(_,i)=>({left:i*PDF_TILE_WIDTH,width:Math.min(PDF_TILE_WIDTH,pixelWidth-i*PDF_TILE_WIDTH)}))};
}
