export function siteUrl(path:string){if(/^https?:\/\//i.test(path))return path;return new URL(path.replace(/^\//,''),new URL('../',document.baseURI)).href;}
