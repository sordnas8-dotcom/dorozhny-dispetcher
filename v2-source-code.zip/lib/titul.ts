import {departmentName,compareDepartments} from './departments';
import * as XLSX from 'xlsx';
export type Metric={key:string;label:string};
export type Department={name:string;sheet:string;totalLabel:string;totalRow:number;metrics:Record<string,number|string|null>;objects:{id:string;name:string;number?:string;category?:string;row:number;additional:boolean;metrics:Record<string,number|string|null>}[];warnings:string[]};
export type Titul={format:1;filename:string;importedAt:string;departments:Department[];metrics:Metric[];warnings:string[]};
const clean=(v:unknown)=>String(v??'').replace(/\s+/g,' ').trim();
const key=(s:string)=>s.toLowerCase().replace(/ё/g,'е').replace(/[^\p{L}\p{N}]+/gu,' ').trim();
const deptName=departmentName;
function scalar(v:unknown):number|string|null{return typeof v==='number'&&Number.isFinite(v)?v:typeof v==='string'&&v.trim()?v.trim():null}
export function parseTitul(w:XLSX.WorkBook,filename:string):Titul{
 if(w.SheetNames.length>100)throw Error('Слишком много листов. Допустимо до 100.');
 const result:Titul={format:1,filename,importedAt:new Date().toISOString(),departments:[],metrics:[],warnings:[]};
 const metricMap=new Map<string,Metric>();
 for(const sheet of w.SheetNames){
 const ws=w.Sheets[sheet];if(!ws['!ref'])continue;const range=XLSX.utils.decode_range(ws['!ref']);if(range.e.r>50000||range.e.c>500)throw Error(`Лист «${sheet}» превышает допустимый размер.`);
 const rows=XLSX.utils.sheet_to_json<unknown[]>(ws,{header:1,defval:null,raw:true});
 const h=rows.findIndex(r=>r.some(v=>/наименование\s*одх/i.test(clean(v))));
 if(h<0||!/^(\d+(?:\s*юг)?|арбат.*|инженер.*|(?:УСЭ\s*)?МКАД.*|ТТК|Парк\s*Победы)$/i.test(sheet.trim()))continue;
 const namecol=rows[h].findIndex(v=>/наименование\s*одх/i.test(clean(v)));const idcol=namecol+1;
 const cols=rows[h].length;const header=rows.slice(h,h+5).map(r=>[...r]);
 for(const merge of ws['!merges']||[]){if(merge.s.r<h||merge.s.r>h+4)continue;const v=rows[merge.s.r]?.[merge.s.c];for(let r=merge.s.r;r<=Math.min(merge.e.r,h+4);r++)for(let c=merge.s.c;c<=merge.e.c;c++){header[r-h]??=[];header[r-h][c]=v;}}
 const numbered=rows.findIndex((r,i)=>i>h&&i<h+8&&clean(r[0])==='1'&&clean(r[1])==='2'&&clean(r[2])==='3');
 const start=numbered>=0?numbered+1:h+4;
 const labels=new Map<number,string>();
 for(let c=idcol+1;c<cols;c++){
 const pieces:string[]=[];for(let r=h;r<Math.min(start,h+5);r++){const v=clean(header[r-h]?.[c]);if(v&&!/^\d+$/.test(v)&&!/в том числе/i.test(v)&&!pieces.includes(v))pieces.push(v)}
 if(!pieces.length)continue;const label=pieces.join(' · '),k=key(label);labels.set(c,k);metricMap.set(k,{key:k,label});}
 const getValues=(r:unknown[],ri:number)=>{const vals:Department['metrics']={};for(const [c,k]of labels){const cell=ws[XLSX.utils.encode_cell({r:ri,c})];if(cell?.f&&cell.v==null)throw Error(`В листе «${sheet}», ячейка ${XLSX.utils.encode_cell({r:ri,c})}: у формулы нет сохранённого результата. Пересчитайте файл в Excel и сохраните.`);vals[k]=scalar(r[c])}return vals};
 const totals=rows.map((r,i)=>({r,i,label:clean(r[namecol])})).filter(x=>x.i>=start&&/^итого\s+по\s+(дэу|ао\s|инженер|арбат)/i.test(x.label));
 if(!totals.length){result.warnings.push(`Лист «${sheet}»: итог по подразделению не найден — не импортирован.`);continue;}
 const withAdd=totals.filter(x=>/с\s+доп/i.test(x.label));const total=(withAdd.length?withAdd:totals).at(-1)!;
 const department:Department={name:deptName(sheet.trim()),sheet,totalLabel:total.label,totalRow:total.i+1,metrics:getValues(total.r,total.i),objects:[],warnings:[]};
 const firstTotal=totals[0].i;
 let category='';for(let i=start;i<total.i;i++){const r=rows[i];const name=clean(r[namecol]);const id=clean(r[idcol]);if(!id&&name&&/категор/i.test(name)&&!/^итого/i.test(name)&&r[idcol+1]==null)category=name;if(!name||!/^[\d]+$/.test(id)||/^итого|^всего/i.test(name))continue;department.objects.push({id,name,number:clean(r[0]),category,row:i+1,additional:i>firstTotal,metrics:getValues(r,i)});}
 const unique=new Set(department.objects.filter(x=>!x.additional).map(x=>x.id));
 if(!unique.size)department.warnings.push('Перечень объектов не распознан. Проверьте исходный лист.');
 result.departments.push(department);
 }
 // A summary has departments in columns and indicators in rows.
 if(!result.departments.length){
 const candidates=w.SheetNames.map((s,i)=>({s,i,date:/^\d{2}\.\d{2}\.\d{4}$/.test(s)?s.split('.').reverse().join(''):''})).sort((a,b)=>(b.date||'').localeCompare(a.date||'')||b.i-a.i);
 for(const {s:sheet}of candidates){const ws=w.Sheets[sheet];const rows=XLSX.utils.sheet_to_json<unknown[]>(ws,{header:1,defval:null,raw:true});const hi=rows.findIndex(r=>r.filter(v=>typeof v==='number'&&v>0&&v<100).length>=8);if(hi<0)continue;const heads=rows[hi];
 const deps=heads.map((v,c)=>({name:deptName(clean(v)),c,raw:clean(v)})).filter(x=>/^\d+(?:\s*юг)?$/i.test(x.raw)||/^(арбат|атбат|инж)/i.test(x.raw));if(!deps.length)continue;
 const labels=new Map<number,string>();let parent='';for(let ri=hi+1;ri<rows.length;ri++){const r=rows[ri],parts=r.slice(0,4).map(clean).filter(v=>v&&!/в том числе/i.test(v));if(!parts.length||!deps.some(d=>typeof r[d.c]==='number'))continue;if(parts[0]&&!/^(мех|ручн|по )/i.test(parts[0]))parent=parts[0];if(parts[0]&&/^(мех|ручн|по )/i.test(parts[0])&&parent)parts.unshift(parent);const label=parts.join(' · '),k=key(label);metricMap.set(k,{key:k,label});labels.set(ri,k)}
 for(const d of deps){const vals:Department['metrics']={};for(const [ri,k]of labels)vals[k]=scalar(rows[ri][d.c]);result.departments.push({name:d.name,sheet,totalLabel:'Итоги сводного титула',totalRow:hi+1,metrics:vals,objects:[],warnings:['Сводный титул содержит итоговые показатели. Пообъектный перечень в этой версии отсутствует.']})}result.warnings.push('Импортирован сводный титул. Для перечня ОДХ загрузите титул по ДЭУ.');break;}
 }
 if(!result.departments.length)throw Error('ДЭУ не распознаны. Поддерживаются титул по листам ДЭУ и сводный титул с подразделениями в колонках.');
 result.metrics=[...metricMap.values()];return normalizeTitul(result);
}
export function readTitul(bytes:ArrayBuffer|Uint8Array,filename:string){return parseTitul(XLSX.read(bytes,{type:'array',cellFormula:true,cellDates:false,sheetRows:50001}),filename)}
export function compareTitul(prev:Titul,next:Titul){const before=new Map(prev.departments.map(d=>[d.name,d]));let changed=0,added=0;for(const d of next.departments){const old=before.get(d.name);if(!old){added++;continue}for(const k of new Set([...Object.keys(old.metrics),...Object.keys(d.metrics)])){if(old.metrics[k]!==d.metrics[k])changed++}}return {changed,added,removed:prev.departments.filter(d=>!next.departments.some(x=>x.name===d.name)).length}}

export function normalizeTitul(title:Titul):Titul {
 const groups=new Map<string,Department>();
 for(const source of title.departments){const name=departmentName(source.name),old=groups.get(name);
 if(!old){groups.set(name,{...source,name,objects:[...source.objects]});continue;}
 // Alias-only copies do not duplicate objects or their area totals.
 const signature=(d:Department)=>JSON.stringify([d.metrics,d.objects.map(o=>[o.id,o.additional,o.metrics])]);
 if(signature(old)===signature(source))continue;
 const values={...old.metrics};for(const [key,value] of Object.entries(source.metrics)){const before=values[key];values[key]=typeof before==='number'&&typeof value==='number'?before+value:before??value;}
 groups.set(name,{...old,metrics:values,objects:[...old.objects,...source.objects],warnings:[...new Set([...old.warnings,...source.warnings])],totalLabel:'Итого по '+name,sheet:old.sheet+' / '+source.sheet});
 }
 return {...title,departments:[...groups.values()].sort((a,b)=>compareDepartments(a.name,b.name))};
}
