import rawSeed from './cleaning-schemes.json';
const seed=rawSeed as {filename:string;name:string;season:string}[];
export function schemeUploadMetadata(filename:string){
 const known=seed.find(f=>f.filename===filename);if(known)return {name:known.name,season:known.season};
 const bare=filename.replace(/\.pdf$/i,'').trim();
 const match=bare.match(/(зима|лето)\s*(\d{4})(?:\s*[-–—]\s*(\d{2,4}))?/i);
 let season='';if(match){const end=match[3]?(match[3].length===2?match[2].slice(0,2)+match[3]:match[3]):'';season=(/^зима$/i.test(match[1])?'Зима ':'Лето ')+match[2]+(end?'–'+end:'');}
 const name=bare.replace(/^ДЭУ[\s-]*\d+(?:\s*\([^)]*\))?\s*/i,'').replace(match?.[0]||'\0','').replace(/[\s._-]+$/,'').trim()||bare;
 return {name:name.slice(0,300),season};
}
