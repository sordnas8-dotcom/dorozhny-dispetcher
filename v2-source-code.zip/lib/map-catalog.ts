import data from './map-data.json';
export type MapKind=keyof typeof data;
export type MapPoint={id:string;number:string;code:string;name:string;group:string;color:string;lat:number;lon:number;filters:string[];fields:Record<string,string>};
export type MapColumn={label:string;field:string};
export const mapData=data as Record<MapKind,{mapId:string;rows:MapPoint[]}>;
export const mapCatalog:Record<MapKind,{title:string;tag:string;subtitle:string;placeholder:string;filter:string;all:string;columns:MapColumn[]}>= {
 ssp:{title:'ССП Москвы',tag:'ССП',subtitle:'45 снегосплавных пунктов · по владельцам',placeholder:'Номер, код, название или адрес ССП',filter:'Владелец ССП',all:'Все владельцы',columns:[{label:'Код ССП',field:'Код ССП'},{label:'Адрес',field:'Адрес ССП'},{label:'Округ',field:'Округ'},{label:'Производительность',field:'Производительность'}]},
 reagents:{title:'Базы реагентов',tag:'Базы реагентов',subtitle:'36 баз · оранжевые метки',placeholder:'Номер или адрес базы реагентов',filter:'Организация базы реагентов',all:'Все организации',columns:[{label:'Организация',field:'Организация'},{label:'Адрес',field:'Адрес базы'}]},
 deu:{title:'Базы ДЭУ',tag:'Базы ДЭУ',subtitle:'27 адресов баз · красные метки',placeholder:'ДЭУ или адрес базы',filter:'Подразделение базы',all:'Все подразделения',columns:[{label:'Подразделения',field:'Подразделения'},{label:'Адрес',field:'Адрес базы'}]},
 tow:{title:'Расстановка тягачей',tag:'Тягачи',subtitle:'Посты дежурства · МКАД и ТиНАО',placeholder:'Номер, подразделение или адрес поста',filter:'Группа тягачей',all:'Все группы',columns:[{label:'Группа',field:'Группа'},{label:'Территория',field:'Территория'},{label:'Подразделение',field:'Подразделение, предоставляющее тягачи'},{label:'Адрес расстановки',field:'Адрес расстановки'},{label:'Количество',field:'Количество тягачей, ед.'}]},
 aps:{title:'Автомобильные противогололёдные системы',tag:'АПС',subtitle:'122 системы · цвета по состоянию',placeholder:'Номер, объект, адрес или комментарий',filter:'Цвет АПС по таблице',all:'Все цвета',columns:[{label:'Адрес / ориентир',field:'Адрес Ориентир'},{label:'Количество БДГ',field:'Кол-во БДГ'},{label:'Комментарий',field:'Комментарий'}]},
};
export const mapKinds:MapKind[]=['ssp','reagents','deu','tow','aps'];
export function filterMapPoints(points:MapPoint[],group:string,query:string){
 const q=query.trim().toLocaleLowerCase('ru').replace(/ё/g,'е');
 return points.filter(p=>(!group||p.filters.includes(group))&&(!q||[p.number,p.code,p.name,p.group,...p.filters,...Object.values(p.fields)].join(' ').toLocaleLowerCase('ru').replace(/ё/g,'е').includes(q)));
}

// Keep location data intact; show one coordinate pair in each website card.
export function withoutCoordinatePairs(value:string){
 return value.replace(/[([]?\s*-?\d{1,3}\.\d{3,}\s*[,;]\s*-?\d{1,3}\.\d{3,}\s*[)\]]?/g,'').trim();
}
export function mapPointDetails(point:MapPoint):[string,string][]{
 const fields=Object.entries(point.fields).flatMap(([key,value]):[string,string][]=>{
  if(/источник|точность точки|^(?:широта|долгота|latitude|longitude)$|^координаты(?:\s|$)/i.test(key))return [];
  const clean=withoutCoordinatePairs(value);
  return clean?[[key==='Уточнение координат'?'Уточнение расположения':key,clean]]:[];
 });
 return [...fields,['Координаты',`${point.lat}, ${point.lon}`]];
}
