import {departmentName} from './departments';
import * as XLSX from 'xlsx';
export type Contact={id:string;departments:string[];group:string;name:string;role:string;phone:string;email:string;base:string;roads:string;sheet:string;row:number};
export type ContactBook={filename:string;updatedAt:string;contacts:Contact[];warnings:string[];departmentDetails?:Record<string,{base:string;email:string}>};
const clean=(v:unknown)=>String(v??'').replace(/\u00a0/g,' ').replace(/[ \t]+/g,' ').trim();
export const normalizeDeu=departmentName;
export function parseContacts(bytes:Uint8Array|ArrayBuffer,filename:string):ContactBook{
 const w=XLSX.read(bytes,{type:'array',sheetRows:5001,cellFormula:false});if(w.SheetNames.length>50)throw Error('В файле слишком много листов.');
 const book:ContactBook={filename,updatedAt:new Date().toISOString(),contacts:[],warnings:[]};
 for(const sheet of w.SheetNames){const ws=w.Sheets[sheet];if(!ws['!ref'])continue;const range=XLSX.utils.decode_range(ws['!ref']);if(range.e.r>5000)throw Error('Допустимо до 5000 строк на листе.');
 const rows=XLSX.utils.sheet_to_json<unknown[]>(ws,{header:1,defval:'',raw:false,range:{s:{r:0,c:0},e:{r:Math.min(range.e.r,5000),c:Math.min(range.e.c,29)}}});
 const hi=rows.findIndex(r=>r.some(v=>/телефон/i.test(clean(v)))&&r.some(v=>/должност|ф\.?\s*и\.?\s*о|фио/i.test(clean(v))));if(hi<0)continue;
 const find=(re:RegExp)=>rows[hi].findIndex(v=>re.test(clean(v)));const cols={deu:find(/^дэу$|подраздел|участок/i),name:find(/ф\.?\s*и\.?\s*о|фио|сотрудник/i),role:find(/должност/i),phone:find(/телефон/i),base:find(/адрес.*баз|адрес баз/i),email:find(/почт|e.?mail/i),roads:find(/одх|объект/i)};
 if(cols.deu<0){book.warnings.push(`Лист «${sheet}»: колонка ДЭУ не найдена.`);continue;}
 let group='',departments:string[]=[],base='',email='',roads='';const scope=/озелен|дэу оо/i.test(sheet)?'Озеленение · ':'';
 for(let i=hi+1;i<rows.length;i++){const r=rows[i];const get=(c:number)=>c<0?'':clean(r[c]);const label=get(cols.deu);
 if(label){group=label;departments=label.split(/[,;\n]+/).map(v=>scope+normalizeDeu(v)).filter(v=>v.trim()&&!/^москва-сити$/i.test(v));base='';email='';roads='';}
 if(!group)continue;const newBase=get(cols.base),newEmail=get(cols.email),newRoads=get(cols.roads);if(newBase)base=newBase;if(newEmail)email=newEmail;if(newRoads)roads=newRoads;
 const name=get(cols.name),role=get(cols.role),phone=get(cols.phone);if(!name&&!role&&!phone&&!newBase&&!newEmail)continue;
 book.contacts.push({id:`${sheet}:${i+1}`,departments:[...departments],group:scope+group,name,role,phone,email,base,roads,sheet,row:i+1});
 }
 }
 if(!book.contacts.length)throw Error('Контакты не распознаны. Нужны колонки «ДЭУ», «Ф.И.О», «Должность», «Телефон».');return book;
}
export function contactChanges(before:ContactBook,after:ContactBook){const key=(c:Contact)=>[c.sheet,c.group,c.role,c.name].join('|');const a=new Map(before.contacts.map(c=>[key(c),JSON.stringify(c)])),b=new Map(after.contacts.map(c=>[key(c),JSON.stringify(c)]));return {added:[...b.keys()].filter(k=>!a.has(k)).length,removed:[...a.keys()].filter(k=>!b.has(k)).length,changed:[...b.keys()].filter(k=>a.has(k)&&a.get(k)!==b.get(k)).length}}

export function normalizeContactBook(book:ContactBook):ContactBook {
 const details:NonNullable<ContactBook['departmentDetails']>={};
 for(const [name,value] of Object.entries(book.departmentDetails||{}))details[departmentName(name)]={...details[departmentName(name)],...value};
 return {...book,contacts:book.contacts.map(c=>({...c,departments:[...new Set(c.departments.map(departmentName))]})),departmentDetails:details};
}
