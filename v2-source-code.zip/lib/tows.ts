import * as XLSX from 'xlsx';
import {mapData,withoutCoordinatePairs,type MapPoint} from './map-catalog';
export type TowBook={filename:string;sheet:string;updatedAt:string;rows:MapPoint[]};
export const initialTows:TowBook={filename:'Текущий перечень тягачей',sheet:'Тягачи',updatedAt:'',rows:mapData.tow.rows};
const text=(v:unknown)=>String(v??'').replace(/\s+/g,' ').trim();
const norm=(v:unknown)=>text(v).replace(/№/g,'номер ').toLowerCase().replace(/ё/g,'е').replace(/[^\p{L}\p{N}]+/gu,' ').trim();
export function towWorkbook(bytes:ArrayBuffer){const w=XLSX.read(bytes,{type:'array',cellDates:false});if(w.SheetNames.length>100)throw Error('Допустимо до 100 листов.');return w;}
export function parseTows(bytes:ArrayBuffer,filename:string,sheet?:string):TowBook{
 const w=towWorkbook(bytes);const name=sheet||w.SheetNames[0];const ws=w.Sheets[name];if(!ws?.['!ref'])throw Error('Выбранный лист пуст.');
 const range=XLSX.utils.decode_range(ws['!ref']);if(range.e.r>10000||range.e.c>150)throw Error('Лист слишком большой: допустимо до 10 000 строк и 150 столбцов.');
 const grid=XLSX.utils.sheet_to_json<unknown[]>(ws,{header:1,defval:'',raw:false});
 const number=(h:string)=>/^(?:номер|номер п п|номер п п общий|номер поста|номер поста по полному перечню|п п|п п общий|в полном перечне|поста по полному перечню|поста|номер в полном перечне)$/.test(h);
 const address=(h:string)=>/адрес|место (?:расстановки|дежурства)|место дислокации/.test(h);
 const hi=grid.findIndex((r,i)=>i<60&&r.some(v=>number(norm(v)))&&r.some(v=>address(norm(v))));
 if(hi<0)throw Error('Не найдены столбцы «№» и «Адрес расстановки». Выберите другой лист или используйте шаблон.');
 const headers=grid[hi].map(text),keys=headers.map(norm);
 const find=(fn:(s:string)=>boolean)=>keys.findIndex(fn);
 const ni=find(number),ai=find(address),ci=find(h=>/^координаты/.test(h)),lati=find(h=>/^(широта|latitude|lat)$/.test(h)),loni=find(h=>/^(долгота|longitude|lon|lng)$/.test(h));
 if(ci<0&&(lati<0||loni<0)&&!grid.slice(hi+1).some(r=>/\d{2}\.\d+\s*[,;]\s*\d{2}\.\d+/.test(text(r[ai]))))throw Error('Нужны координаты: один столбец «Координаты» или два — «Широта» и «Долгота».');
 const gi=find(h=>/^группа$/.test(h)),di=find(h=>/подразделение/.test(h)),ti=find(h=>/^территория$/.test(h)),qi=find(h=>/количество тягачей|кол во тягачей|^количество$/.test(h)),namei=find(h=>/^наименование$|^название$|^пост$/.test(h));
 const errors:string[]=[],rows:MapPoint[]=[],seen=new Set<string>();
 for(let i=hi+1;i<grid.length;i++){
  const r=grid[i],n=text(r[ni]),a=text(r[ai]);if(!n&&!a)continue;if(/^итого|^всего/i.test(n)||/^итого|^всего/i.test(a))continue;
  if(!/^\d+$/.test(n)){errors.push(`Строка ${i+1}: неверный номер поста.`);continue;}
  const postKey=norm(r[ti])+'|'+n;
  if(seen.has(postKey)){errors.push(`Строка ${i+1}: повтор номера ${n}.`);continue;}seen.add(postKey);
  if(!a){errors.push(`Строка ${i+1}: нет адреса.`);continue;}
  let lat:number,lon:number;
  if(lati>=0&&loni>=0){lat=Number(text(r[lati]).replace(',','.'));lon=Number(text(r[loni]).replace(',','.'));if(!text(r[lati])||!text(r[loni]))lat=NaN;}
  else {const pair=text(ci>=0?r[ci]:a).match(/(-?\d{1,3}\.\d+)\s*[,;]\s*(-?\d{1,3}\.\d+)/);lat=pair?Number(pair[1]):NaN;lon=pair?Number(pair[2]):NaN;}
  if(!Number.isFinite(lat)||!Number.isFinite(lon)||lat<54||lat>57||lon<35||lon>40){errors.push(`Строка ${i+1}: проверьте координаты Москвы и области (широта, долгота).`);continue;}
  const old=mapData.tow.rows.find(p=>Math.abs(p.lat-lat)<0.00001&&Math.abs(p.lon-lon)<0.00001);
  const group=text(r[gi])||old?.group||'Остальные тягачи',color=/^13\b|первая|первой/i.test(group)?'#FF5252':'#0288D1';
  const quantity=text(r[qi])||'1';if(!/^\d+$/.test(quantity)||Number(quantity)<1){errors.push(`Строка ${i+1}: количество тягачей должно быть положительным целым числом.`);continue;}
  const fields:Record<string,string>={};headers.forEach((h,c)=>{if(h&&text(r[c]))fields[h]=text(r[c]);});
  Object.assign(fields,{'№ в полном перечне':n,'Группа':group,'Территория':text(r[ti]),'Подразделение, предоставляющее тягачи':text(r[di]),'Адрес расстановки':a,'Количество тягачей, ед.':quantity,'Координаты':`${lat}, ${lon}`});
  rows.push({id:`tow-${i}-${n}`,number:n,code:'',name:text(r[namei])||`${text(r[ti])||'Тягач'} — пост ${n}`,group,color,lat,lon,filters:[group],fields});
 }
 if(errors.length)throw Error(errors.slice(0,8).join('\n')+(errors.length>8?`\nЕщё ошибок: ${errors.length-8}`:''));
 if(!rows.length)throw Error('На выбранном листе не найдено постов тягачей.');
 if(rows.length>2000)throw Error('Допустимо до 2 000 постов.');
 const territories=[...new Set(rows.map(p=>p.fields['Территория']))];
 return {filename,sheet:name,updatedAt:new Date().toISOString(),rows:rows.sort((a,b)=>territories.indexOf(a.fields['Территория'])-territories.indexOf(b.fields['Территория'])||Number(a.number)-Number(b.number))};
}
const xml=(v:unknown)=>String(v).replace(/[<>&"']/g,c=>({'<':'&lt;','>':'&gt;','&':'&amp;','"':'&quot;',"'":'&apos;'}[c]!));
export function towsKml(book:TowBook){return `<?xml version="1.0" encoding="UTF-8"?><kml xmlns="http://www.opengis.net/kml/2.2"><Document><name>Расстановка тягачей</name>${book.rows.map(p=>`<Placemark><name>${xml(p.number+' — '+p.name)}</name><Style><IconStyle><color>${p.color==='#FF5252'?'ff5252ff':'ffd18802'}</color></IconStyle></Style><ExtendedData>${Object.entries(p.fields).filter(([k])=>!/источник|координат|широта|долгота|latitude|longitude/i.test(k)).map(([k,v])=>`<Data name="${xml(k)}"><value>${xml(withoutCoordinatePairs(v))}</value></Data>`).join('')}<Data name="Координаты"><value>${p.lat}, ${p.lon}</value></Data></ExtendedData><Point><coordinates>${p.lon},${p.lat},0</coordinates></Point></Placemark>`).join('')}</Document></kml>`;}
export function towTemplate(rows:MapPoint[]){const w=XLSX.utils.book_new();XLSX.utils.book_append_sheet(w,XLSX.utils.json_to_sheet(rows.map(p=>({'№':p.number,'Наименование':p.name,'Группа':p.group,'Территория':p.fields['Территория'],'Подразделение':p.fields['Подразделение, предоставляющее тягачи'],'Адрес расстановки':p.fields['Адрес расстановки'],'Количество тягачей':p.fields['Количество тягачей, ед.']||'1','Широта':p.lat,'Долгота':p.lon,'Примечание':p.fields['Примечание']||''}))),'Тягачи');return w;}
