import {departmentName,compareDepartments} from './departments';
import type {Contact,ContactBook} from './contacts';
export function compactContactGroups(book:ContactBook,query='',department=''){
 const groups=new Map<string,Contact[]>();for(const c of book.contacts.filter(isDisplayContact))for(const name of new Set(c.departments.map(departmentName))){if(department&&name!==departmentName(department))continue;const rows=groups.get(name)||[];if(!rows.some(r=>r.id===c.id))rows.push(c);groups.set(name,rows)}
 for(const rows of groups.values())rows.sort((a,b)=>contactRoleOrder(a)-contactRoleOrder(b)||a.row-b.row);
 const q=query.toLowerCase().replace(/ё/g,'е').trim();
 return [...groups].map(([name,contacts])=>{const score=(c:Contact)=>{const deputy=/зам|заместител/i.test(c.role),head=/начальник/i.test(c.role)&&!deputy;return (c.name.trim()?1000:0)+(head?(/дэу/i.test(c.role)||c.departments.length===1?500:300):deputy?400:/старш/i.test(c.role)?100:0)+(c.departments.length===1?20:0)};const primary=[...contacts].sort((a,b)=>score(b)-score(a))[0];const matching=q?contacts.filter(c=>`${name} ${c.name} ${c.role} ${c.phone} ${c.email} ${c.base} ${book.departmentDetails?.[name]?.base||''} ${book.departmentDetails?.[name]?.email||''}`.toLowerCase().replace(/ё/g,'е').includes(q)):contacts;return {department:name,contacts,primary,matching}}).filter(g=>g.matching.length).sort((a,b)=>compareDepartments(a.department,b.department));
}
export type ContactEdits={department:string;base:string;email:string;people:{id:string;name:string;role:string;phone:string}[]};
export function applyContactEdits(book:ContactBook,edits:ContactEdits):ContactBook{
 const applicable=book.contacts.filter(c=>c.departments.some(d=>departmentName(d)===departmentName(edits.department)));const ids=new Set(applicable.map(c=>c.id));if(!applicable.length||edits.people.some(p=>!ids.has(p.id)))throw Error('Контакты подразделения изменились. Обновите страницу.');
 const changes=new Map(edits.people.map(p=>[p.id,p]));return {...book,filename:`Контакты — ручное обновление ${edits.department}.json`,updatedAt:new Date().toISOString(),departmentDetails:{...book.departmentDetails,[edits.department]:{base:edits.base,email:edits.email}},contacts:book.contacts.map(c=>{const edit=changes.get(c.id);if(!edit)return c;const direct=c.departments.length===1;return {...c,name:edit.name,role:edit.role,phone:edit.phone,...(direct?{base:edits.base,email:edits.email}:{})}})};
}

export function isDisplayContact(contact:Contact){
 const role=contact.role;
 return /начальник|мастер/i.test(role)&&!(/начальник/i.test(role)&&/комплекс|\bДК\b|(?:^|\s)ДК(?:\s|$)/i.test(role));
}
export function contactRoleOrder(contact:Contact){
 const role=contact.role;
 return /начальник/i.test(role)?(/зам|заместител/i.test(role)?1:0):/старш/i.test(role)?2:3;
}

