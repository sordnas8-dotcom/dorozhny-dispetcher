import type {Titul} from './titul';
const normal=(s:string)=>s.toLowerCase().replace(/ё/g,'е').replace(/[^\p{L}\p{N}]+/gu,' ').trim();
export const companyIndicators=[
 {id:'area',label:'Общая площадь ОДХ',unit:'м²'},
 {id:'cleaning',label:'Площадь уборки ОДХ',unit:'м²'},
 {id:'road',label:'Площадь уборки проезжей части',unit:'м²'},
 {id:'walkManual',label:'Уборка тротуаров — ручная',unit:'м²'},
 {id:'walkMachine',label:'Уборка тротуаров — механизированная',unit:'м²'},
 {id:'stopArea',label:'Площадь уборки остановок',unit:'м²'},
 {id:'stopCount',label:'Количество остановок',unit:'ед.'},
] as const;
export function companySummary(title:Titul){
 const metrics=title.metrics.map(m=>({...m,normalized:normal(m.label)}));
 const keys=(id:string)=>{
  const starts=(prefix:string)=>metrics.filter(m=>m.normalized.startsWith(prefix));
  if(id==='area')return starts('общая площадь одх');
  if(id==='cleaning')return metrics.filter(m=>/^(общая площадь уборки|площадь уборки одх)(?: |$)/.test(m.normalized));
  if(id==='road'){
   const all=starts('площадь уборки проезжей части');
   const total=all.filter(m=>!/(?:мех|ручн|парковоч|без площади)/.test(m.normalized));
   return total.length?total:all;
  }
  if(id==='walkManual'||id==='walkMachine')return starts('площадь уборки тротуаров').filter(m=>id==='walkManual'?/ручн/.test(m.normalized):/мех/.test(m.normalized));
  if(id==='stopArea')return starts('площадь уборки остановок');
  return metrics.filter(m=>/^количество (?:убираемых )?остановок(?: |$)/.test(m.normalized));
 };
 return companyIndicators.map(indicator=>{
  const fields=keys(indicator.id);let scaled=0,missing=0;
  for(const department of title.departments){let complete=fields.length>0;
   for(const field of fields){const value=department.metrics[field.key];if(typeof value==='number'&&Number.isFinite(value))scaled+=Math.round(value*10000);else complete=false;}
   if(!complete)missing++;
  }
  return {...indicator,value:fields.length?scaled/10000:null,missing};
 });
}
