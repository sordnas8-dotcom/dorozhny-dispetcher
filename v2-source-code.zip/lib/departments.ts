/** Shared names for titles, search and contact imports. */
export function departmentName(value:string):string {
 const text=value.replace(/\s+/g,' ').trim();
 const scope=text.match(/^Озеленение\s*·\s*/i)?.[0]||'';
 const raw=text.slice(scope.length).replace(/^ДЭУ[\s-]*/i,'').trim();
 let name=text.slice(scope.length);
 if(/^МКАД\s*\(\s*14\s*[-–—]\s*41\s*\)$/i.test(raw)||/инженер|^инж\.?$/i.test(raw))name='Инженерный центр';
 else if(/^(?:УСЭ\s*)?(?:МКАД|ТТК|МКАД\s*(?:и|,|\/|\+)\s*ТТК)$/i.test(raw))name='УСЭ МКАД и ТТК';
 else if(/^парк\s*победы$/i.test(raw))name='ДЭУ-38';
 else if(/арбат/i.test(raw))name='ДЭУ Арбат-Л';
 else if(/^\d+(?:\s*юг)?$/i.test(raw))name='ДЭУ-'+raw.replace(/\s*юг$/i,' ЮГ');
 return scope+name;
}
export function compareDepartments(a:string,b:string):number {
 const rank=(name:string)=>{const s=departmentName(name);const n=s.match(/^ДЭУ-(\d+)(.*)$/);return n?Number(n[1])*2+(n[2]?1:0):s==='ДЭУ Арбат-Л'?92:s==='УСЭ МКАД и ТТК'?94:s==='Инженерный центр'?96:100;};
 return rank(a)-rank(b)||a.localeCompare(b,'ru',{numeric:true});
}
