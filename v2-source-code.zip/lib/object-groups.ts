import type {Department} from './titul';
export function groupObjects(objects:Department['objects']){
 const groups=new Map<string,Department['objects']>();
 for(const o of objects){const category=o.category?.trim()||'Категория не указана в титуле';const rows=groups.get(category)||[];rows.push(o);groups.set(category,rows)}
 return [...groups].map(([category,objects])=>({category,objects,count:new Set(objects.map(o=>o.id)).size}));
}
