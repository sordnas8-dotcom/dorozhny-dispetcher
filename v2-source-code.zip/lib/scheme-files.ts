import {departmentName} from './departments';
export type SchemeFile={id:string;department:string;name:string;season:string;filename:string;bytes:number;pdf:string;created?:string;width:number;height:number;tiles:{url:string;width:number}[]};
export const MAX_SCHEME_BYTES=50*1024*1024;
export function mergeSchemes(seed:SchemeFile[],uploaded:SchemeFile[]){
 const key=(f:SchemeFile)=>[departmentName(f.department),f.name,f.season].map(s=>s.trim().replace(/\s+/g,' ').toLowerCase().replace(/ё/g,'е').replace(/[–—]/g,'-')).join('|');
 const latest=new Map<string,SchemeFile>();for(const f of [...seed,...[...uploaded].sort((a,b)=>(a.created||'').localeCompare(b.created||''))])latest.set(key(f),f);return [...latest.values()];
}
export function pdfRange(value:string|null,size:number){
 if(!value)return null;const match=/^bytes=(\d*)-(\d*)$/.exec(value);if(!match||(!match[1]&&!match[2]))throw Error('range');
 let start=match[1]?Number(match[1]):Math.max(0,size-Number(match[2]));let end=match[1]?(match[2]?Math.min(size-1,Number(match[2])):size-1):size-1;
 if(!Number.isSafeInteger(start)||!Number.isSafeInteger(end)||start<0||start>=size||end<start)throw Error('range');return {offset:start,length:end-start+1,end};
}
